{
    reference => "sv00.example.com:5000",
};
