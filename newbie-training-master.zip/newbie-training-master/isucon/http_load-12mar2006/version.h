/* version.h - version define for http_load */

#ifndef _VERSION_H_
#define _VERSION_H_

#define VERSION "kayac-isucon/0.1"

#endif /* _VERSION_H_ */
