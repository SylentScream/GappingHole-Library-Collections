file_cache_path           "/tmp/chef-solo"
cookbook_path             [ "/tmp/chef-solo/cookbooks" ]
