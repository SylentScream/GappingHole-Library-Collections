# Iced Penguin Syntax theme

A dark syntax theme inspired by the ice world and penguins.

## Why penguin?

Just because I love penguins.

## Features

- Based on cold colors.
- Focus on visibility.

## Install

Search for `iced-penguin-syntax` in Atom's Settings > Install > Themes.

Or use apm command:

```
apm install iced-penguin-syntax
```

## Screenshot

![screenshot](https://docs.google.com/drawings/d/e/2PACX-1vSazMsOe-SlSQN_42aAGcwbi_HSg9cqYEAI-o2-OYfTVj7cTbesBBnaB8Y0WxMI4vmg0bxGXaW03Gq2/pub?w=957&h=679)
